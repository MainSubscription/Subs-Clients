﻿Imports System.Net.Http
Imports Newtonsoft.Json
Imports System.Text

Public Class Security
    ' URL and API Key for Supabase
    Private apiUrl As String = "https://azglsnlhsuinvibdfogc.supabase.co/rest/v1/Account"
    Private apiKey As String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF6Z2xzbmxoc3VpbnZpYmRmb2djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI4NDE3MzksImV4cCI6MjA0ODQxNzczOX0.-zSytP-ac5mk0ExNa3GuLsOus2_fNepBOpQJqQKYn2Q"

    Private Sub Password_KeyDown(sender As Object, e As KeyEventArgs) Handles Passwordtxt.KeyDown
        If e.KeyCode = Keys.Enter Then
            AuthenticateUser()
        End If
    End Sub

    Private Sub User_KeyDown(sender As Object, e As KeyEventArgs) Handles User.KeyDown
        If e.KeyCode = Keys.Enter Then
            Passwordtxt.Focus()
        End If
    End Sub

    Private Sub Password_Enter(sender As Object, e As EventArgs) Handles Passwordtxt.Enter
        If User.Text = "" Then
            User.Focus()
        End If
    End Sub

    ' Function to authenticate user against Supabase
    Private Async Sub AuthenticateUser()
        Try
            Dim userid As String = User.Text.Trim()  ' Assuming User is the username TextBox
            Dim password As String = Passwordtxt.Text.Trim()  ' Assuming Password is the password TextBox

            If String.IsNullOrEmpty(userid) OrElse String.IsNullOrEmpty(password) Then
                MessageBox.Show("Please enter both user and password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            ' Define Supabase URL and API Key (Anon Key)
            Dim url As String = $"{apiUrl}?select=Name,Power,User&User=eq.{userid}&Password=eq.{password}"

            ' Create HttpClient to send the request
            Using client As New HttpClient()
                client.DefaultRequestHeaders.Add("apikey", apiKey)
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " & apiKey)

                ' Send the GET request to Supabase with query
                Dim response As HttpResponseMessage = Await client.GetAsync(url)

                If response.IsSuccessStatusCode Then
                    ' Read the response content (data from the Account table)
                    Dim responseBody As String = Await response.Content.ReadAsStringAsync()

                    ' Deserialize response to check if the user exists
                    Dim accountData As List(Of Dictionary(Of String, Object)) = JsonConvert.DeserializeObject(Of List(Of Dictionary(Of String, Object)))(responseBody)

                    If accountData.Count > 0 Then
                        NameLogin = accountData(0)("Name").ToString()
                        Power = accountData(0)("Power").ToString()
                        My.Settings.LastUser = userid
                        My.Settings.Save()
                        Me.Hide()
                        Editor.Show()
                    Else
                        ' Invalid credentials
                        MessageBox.Show("Invalid username or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    ' Handle failure response
                    MessageBox.Show("Error: Unable to authenticate", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End Using
        Catch ex As Exception
            ' Handle failure response
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Security_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If My.Settings.LastUser <> "" Then
            User.Text = My.Settings.LastUser
            Passwordtxt.Focus()
            Timer1.Start()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Passwordtxt.Focus()
        Timer1.Stop()
    End Sub
End Class

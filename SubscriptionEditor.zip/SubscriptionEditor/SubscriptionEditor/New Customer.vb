﻿Imports System.Globalization
Imports System.Net.Http
Imports Newtonsoft.Json
Imports System.Text
Public Class New_Customer
    Public Shared ReadOnly Property Patch As New HttpMethod("PATCH")
    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles Guna2Button5.Click
        Tagstxt.Text = "STEAMER.CHAOS.SENI.AFK.SIENA"
    End Sub

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        Tagstxt.Text = "STEAMER.CHAOS.SENI.AFK.SIENA.ADX.AHV"
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        Tagstxt.Text = "STEAMER.CHAOS.SENI.AFK.SIENA.ADX.AHV.ARH.AIC.EOP.ECA"
    End Sub

    Private Sub New_Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Expiration.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub Day7_Click(sender As Object, e As EventArgs) Handles Day7.Click
        ' Parse the date from TextBox1
        Dim inputDate As Date
        If Date.TryParseExact(Expiration.Text, "yyyy/MM/dd", CultureInfo.InvariantCulture, DateTimeStyles.None, inputDate) Then
            ' Add 7 days to the parsed date
            Dim newDate As Date = inputDate.AddDays(7)
            ' Update the textbox with the new date
            Expiration.Text = newDate.ToString("yyyy/MM/dd")
        Else
            Expiration.Text = Date.Now.ToString("yyyy/MM/dd")
            Day7.PerformClick()
        End If
    End Sub

    Private Sub Day15_Click(sender As Object, e As EventArgs) Handles Day15.Click
        ' Parse the date from TextBox1
        Dim inputDate As Date
        If Date.TryParseExact(Expiration.Text, "yyyy/MM/dd", CultureInfo.InvariantCulture, DateTimeStyles.None, inputDate) Then
            ' Add 7 days to the parsed date
            Dim newDate As Date = inputDate.AddDays(15)
            ' Update the textbox with the new date
            Expiration.Text = newDate.ToString("yyyy/MM/dd")
        Else
            Expiration.Text = Date.Now.ToString("yyyy/MM/dd")
            Day15.PerformClick()
        End If
    End Sub

    Private Sub Day30_Click(sender As Object, e As EventArgs) Handles Day30.Click
        ' Parse the date from TextBox1
        Dim inputDate As Date
        If Date.TryParseExact(Expiration.Text, "yyyy/MM/dd", CultureInfo.InvariantCulture, DateTimeStyles.None, inputDate) Then
            ' Add 7 days to the parsed date
            Dim newDate As Date = inputDate.AddDays(30)
            ' Update the textbox with the new date
            Expiration.Text = newDate.ToString("yyyy/MM/dd")
        Else
            Expiration.Text = Date.Now.ToString("yyyy/MM/dd")
            Day30.PerformClick()
        End If
    End Sub

    Private Sub Expiration_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Expiration.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "/"c AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True ' Ignore the key press if it's not a number or '/'
        End If
    End Sub

    Private Sub Expiration_TextChanged(sender As Object, e As EventArgs) Handles Expiration.TextChanged
        Dim enteredDate As Date
        Dim today As Date = DateTime.Now.Date

        ' Try to parse the date entered in the TextBox
        If Date.TryParse(Expiration.Text, enteredDate) Then
            ' Check if the entered date is today
            If enteredDate = today Then
                Difference.Text = "Date is today."
                Return
            End If

            ' Determine if the entered date is in the past or future
            Dim futureOrPast As String = If(enteredDate > today, "in the future: ", "in the past: ")

            ' Calculate the difference
            Dim tempDate As Date = today
            Dim yearsDifference As Integer = 0
            Dim monthsDifference As Integer = 0
            Dim daysDifference As Integer = 0

            ' Calculate years
            While tempDate.AddYears(1) <= enteredDate
                tempDate = tempDate.AddYears(1)
                yearsDifference += 1
            End While

            ' Calculate months
            While tempDate.AddMonths(1) <= enteredDate
                tempDate = tempDate.AddMonths(1)
                monthsDifference += 1
            End While

            ' Calculate days
            daysDifference = (enteredDate - tempDate).Days

            ' Build the result message
            Dim result As String = $"Date is {futureOrPast}"
            If yearsDifference > 0 Then result &= $"{yearsDifference} year(s), "
            If monthsDifference > 0 Then result &= $"{monthsDifference} month(s), "
            result &= $"{daysDifference} day(s)."

            ' Update the label
            Difference.Text = result
        Else
            ' Handle invalid date input
            Difference.Text = "Please enter a valid date."
        End If
    End Sub

    Private Async Sub Submit_Click(sender As Object, e As EventArgs) Handles Submit.Click
        If Nametxt.Text = "" Then
            Exit Sub
        ElseIf Tagstxt.Text = "" Then
            Exit Sub
        ElseIf Keytxt.Text = "" Then
            Exit Sub
        ElseIf Expiration.Text = "" Then
            Exit Sub
        End If


        Dim targetWords As List(Of String) = New List(Of String)({"STEAMER", "SENI", "CHAOS", "ECA", "ARH", "AIC", "ADX", "EOP", "AHV"})
        Dim inputText As String = Tagstxt.Text
        ' Check if any word in the target list exists in the input text
        If Not targetWords.Any(Function(word) inputText.Contains(word)) Then
            MessageBox.Show("Invalid Tags", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim result As DialogResult = MessageBox.Show($"Are you sure you want Add {Nametxt}?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.No Then
            Exit Sub

        End If

        ' Get data from the TextBox controls
        Dim name As String = Nametxt.Text
        Dim expirationDate As String = Expiration.Text
        Dim tags As String = Tagstxt.Text
        Dim key As String = Keytxt.Text

        ' Construct the JSON body for the request
        Dim requestBody As New Dictionary(Of String, String) From {
        {"Name", name},
        {"Date", expirationDate},
        {"Tags", tags},
        {"Key", key}
    }

        ' Convert the dictionary to JSON
        Dim json As String = JsonConvert.SerializeObject(requestBody)

        ' Define the Supabase API URL for inserting data into SubsClient
        Dim url As String = "https://azglsnlhsuinvibdfogc.supabase.co/rest/v1/SubsClient"

        ' Create HttpClient instance
        Using client As New HttpClient()

            ' Create HttpRequestMessage instance
            Dim request As New HttpRequestMessage(HttpMethod.Post, url)

            ' Add Authorization header (Bearer Token) - Make sure it's valid
            request.Headers.Add("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF6Z2xzbmxoc3VpbnZpYmRmb2djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI4NDE3MzksImV4cCI6MjA0ODQxNzczOX0.-zSytP-ac5mk0ExNa3GuLsOus2_fNepBOpQJqQKYn2Q")

            ' Add API Key header (replace 'your-api-key' with your actual public API key)
            request.Headers.Add("apikey", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF6Z2xzbmxoc3VpbnZpYmRmb2djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI4NDE3MzksImV4cCI6MjA0ODQxNzczOX0.-zSytP-ac5mk0ExNa3GuLsOus2_fNepBOpQJqQKYn2Q")

            ' Set Content-Type header
            request.Content = New StringContent(json, Encoding.UTF8, "application/json")

            ' Send the POST request
            Try
                ' Use SendAsync to send the request
                Dim response As HttpResponseMessage = Await client.SendAsync(request)

                ' Check if the response is successful
                If response.IsSuccessStatusCode Then
                    ' Data inserted successfully
                    Editor.dataList.Clear()
                    Editor.dataTable.Clear()
                    Await Editor.FetchAndDisplayData()
                    Me.Close()
                Else
                    ' Display error message if something goes wrong
                    Dim errorDetails As String = Await response.Content.ReadAsStringAsync()
                    MessageBox.Show("Error: " & errorDetails, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Catch ex As Exception
                ' Handle any other errors
                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Me.Close()
    End Sub

    Private Async Sub Update_Click(sender As Object, e As EventArgs) Handles Update.Click
        ' Ensure required fields are filled
        If Nametxt.Text = "" Then
            MessageBox.Show("Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        ElseIf Tagstxt.Text = "" Then
            MessageBox.Show("Tags cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        ElseIf Keytxt.Text = "" Then
            MessageBox.Show("Key cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        ElseIf Expiration.Text = "" Then
            MessageBox.Show("Expiration Date cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim result As DialogResult = MessageBox.Show($"Are you sure you want Update {Nametxt}?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.No Then
            Exit Sub

        End If

        ' Example: ID is retrieved from a TextBox or other control
        If String.IsNullOrWhiteSpace(UpdateID) Then
            MessageBox.Show("ID cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Get data from the TextBox controls
        Dim name As String = Nametxt.Text
        Dim expirationDate As String = Expiration.Text
        Dim tags As String = Tagstxt.Text
        Dim Keysx As String = Keytxt.Text

        ' Construct the JSON body for the request
        Dim requestBody As New Dictionary(Of String, String) From {
            {"Name", name},
            {"Date", expirationDate},
            {"Tags", tags},
            {"Key", Keysx}
        }

        ' Convert the dictionary to JSON
        Dim json As String = JsonConvert.SerializeObject(requestBody)

        ' Define the Supabase API URL for updating data in SubsClient
        ' Append the ID value to the URL to update a specific record
        Dim url As String = $"https://azglsnlhsuinvibdfogc.supabase.co/rest/v1/SubsClient?ID=eq.{UpdateID}"

        ' Create HttpClient instance
        Using client As New HttpClient()

            ' Create HttpRequestMessage instance
            Dim request As New HttpRequestMessage(New HttpMethod("PATCH"), url)

            ' Add Authorization header (Bearer Token)
            request.Headers.Add("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF6Z2xzbmxoc3VpbnZpYmRmb2djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI4NDE3MzksImV4cCI6MjA0ODQxNzczOX0.-zSytP-ac5mk0ExNa3GuLsOus2_fNepBOpQJqQKYn2Q")

            ' Add API Key header
            request.Headers.Add("apikey", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF6Z2xzbmxoc3VpbnZpYmRmb2djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI4NDE3MzksImV4cCI6MjA0ODQxNzczOX0.-zSytP-ac5mk0ExNa3GuLsOus2_fNepBOpQJqQKYn2Q")

            ' Set Content-Type header
            request.Content = New StringContent(json, Encoding.UTF8, "application/json")

            ' Send the PATCH request
            Try
                ' Use SendAsync to send the request
                Dim response As HttpResponseMessage = Await client.SendAsync(request)

                ' Check if the response is successful
                If response.IsSuccessStatusCode Then
                    ' Data updated successfully
                    Editor.dataList.Clear()
                    Editor.dataTable.Clear()
                    Await Editor.FetchAndDisplayData()
                    Me.Close()
                Else
                    ' Display error message if something goes wrong
                    Dim errorDetails As String = Await response.Content.ReadAsStringAsync()
                    MessageBox.Show("Error: " & errorDetails, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Catch ex As Exception
                ' Handle any other errors
                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

End Class
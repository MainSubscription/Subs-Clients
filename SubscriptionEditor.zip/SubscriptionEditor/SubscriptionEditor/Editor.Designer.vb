﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Editor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Editor))
        Me.DataGrid = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Connected = New Guna.UI2.WinForms.Guna2CirclePictureBox()
        Me.Dialogue = New System.Windows.Forms.Label()
        Me.Count = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.Addlist = New System.Windows.Forms.ToolStripButton()
        Me.Update = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BorderShade = New Guna.UI2.WinForms.Guna2BorderlessForm(Me.components)
        Me.Header = New System.Windows.Forms.Label()
        Me.HeaderDrag = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Active = New System.Windows.Forms.ToolStripLabel()
        Me.Expired = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        CType(Me.DataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.Connected, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGrid
        '
        Me.DataGrid.AllowUserToAddRows = False
        Me.DataGrid.AllowUserToDeleteRows = False
        Me.DataGrid.AllowUserToResizeColumns = False
        Me.DataGrid.AllowUserToResizeRows = False
        DataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.DataGrid.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle29
        Me.DataGrid.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DataGrid.BackgroundColor = System.Drawing.Color.White
        Me.DataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(75, Byte), Integer))
        DataGridViewCellStyle30.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle30.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGrid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle30
        Me.DataGrid.ColumnHeadersHeight = 30
        Me.DataGrid.Cursor = System.Windows.Forms.Cursors.Arrow
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle31.Font = New System.Drawing.Font("Calibri", 10.0!)
        DataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGrid.DefaultCellStyle = DataGridViewCellStyle31
        Me.DataGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGrid.EnableHeadersVisualStyles = False
        Me.DataGrid.Location = New System.Drawing.Point(7, 78)
        Me.DataGrid.MultiSelect = False
        Me.DataGrid.Name = "DataGrid"
        Me.DataGrid.ReadOnly = True
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle32.Font = New System.Drawing.Font("Calibri", 12.0!)
        DataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGrid.RowHeadersDefaultCellStyle = DataGridViewCellStyle32
        Me.DataGrid.RowHeadersWidth = 50
        Me.DataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGrid.Size = New System.Drawing.Size(776, 456)
        Me.DataGrid.TabIndex = 46
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Connected)
        Me.Panel1.Controls.Add(Me.Dialogue)
        Me.Panel1.Controls.Add(Me.Count)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.ToolStrip1)
        Me.Panel1.Controls.Add(Me.DataGrid)
        Me.Panel1.Location = New System.Drawing.Point(5, 29)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(790, 566)
        Me.Panel1.TabIndex = 47
        '
        'Connected
        '
        Me.Connected.Image = CType(resources.GetObject("Connected.Image"), System.Drawing.Image)
        Me.Connected.ImageRotate = 0!
        Me.Connected.Location = New System.Drawing.Point(7, 541)
        Me.Connected.Name = "Connected"
        Me.Connected.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Connected.Size = New System.Drawing.Size(21, 16)
        Me.Connected.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Connected.TabIndex = 51
        Me.Connected.TabStop = False
        '
        'Dialogue
        '
        Me.Dialogue.Location = New System.Drawing.Point(27, 538)
        Me.Dialogue.Name = "Dialogue"
        Me.Dialogue.Size = New System.Drawing.Size(360, 18)
        Me.Dialogue.TabIndex = 50
        Me.Dialogue.Text = "Currently no account logged in."
        Me.Dialogue.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Count
        '
        Me.Count.AutoSize = True
        Me.Count.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Count.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Count.Location = New System.Drawing.Point(745, 538)
        Me.Count.Name = "Count"
        Me.Count.Size = New System.Drawing.Size(37, 20)
        Me.Count.TabIndex = 49
        Me.Count.Text = "1000"
        Me.Count.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(700, 538)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 20)
        Me.Label10.TabIndex = 48
        Me.Label10.Text = "Count:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Addlist, Me.Update, Me.ToolStripSeparator2, Me.ToolStripTextBox1, Me.ToolStripButton2, Me.ToolStripSeparator1, Me.Active, Me.Expired, Me.ToolStripSeparator4, Me.ToolStripButton1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(790, 64)
        Me.ToolStrip1.TabIndex = 47
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Addlist
        '
        Me.Addlist.AutoSize = False
        Me.Addlist.Enabled = False
        Me.Addlist.Image = CType(resources.GetObject("Addlist.Image"), System.Drawing.Image)
        Me.Addlist.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Addlist.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Addlist.Name = "Addlist"
        Me.Addlist.Size = New System.Drawing.Size(65, 60)
        Me.Addlist.Text = "&Add List"
        Me.Addlist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'Update
        '
        Me.Update.AutoSize = False
        Me.Update.Enabled = False
        Me.Update.Image = CType(resources.GetObject("Update.Image"), System.Drawing.Image)
        Me.Update.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Update.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Update.Name = "Update"
        Me.Update.Size = New System.Drawing.Size(65, 60)
        Me.Update.Text = "&Update"
        Me.Update.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 64)
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.BackColor = System.Drawing.Color.White
        Me.ToolStripTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(320, 64)
        Me.ToolStripTextBox1.ToolTipText = "Search"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.AutoSize = False
        Me.ToolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(65, 60)
        Me.ToolStripButton2.Text = "&Search"
        Me.ToolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ToolStripButton2.ToolTipText = "Search"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 64)
        '
        'BorderShade
        '
        Me.BorderShade.ContainerControl = Me
        Me.BorderShade.DockForm = False
        Me.BorderShade.DockIndicatorTransparencyValue = 0.6R
        Me.BorderShade.DragStartTransparencyValue = 1.0R
        Me.BorderShade.ResizeForm = False
        Me.BorderShade.TransparentWhileDrag = True
        '
        'Header
        '
        Me.Header.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Header.Font = New System.Drawing.Font("Impact", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Header.ForeColor = System.Drawing.Color.White
        Me.Header.Location = New System.Drawing.Point(5, 3)
        Me.Header.Name = "Header"
        Me.Header.Size = New System.Drawing.Size(790, 23)
        Me.Header.TabIndex = 48
        Me.Header.Text = "Rtool Editor v1.0"
        Me.Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'HeaderDrag
        '
        Me.HeaderDrag.DockIndicatorTransparencyValue = 0.6R
        Me.HeaderDrag.DragStartTransparencyValue = 1.0R
        Me.HeaderDrag.TargetControl = Me.Header
        Me.HeaderDrag.TransparentWhileDrag = False
        '
        'Active
        '
        Me.Active.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Active.ForeColor = System.Drawing.Color.Green
        Me.Active.Name = "Active"
        Me.Active.Size = New System.Drawing.Size(75, 61)
        Me.Active.Text = "Active: 0"
        '
        'Expired
        '
        Me.Expired.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Expired.ForeColor = System.Drawing.Color.Red
        Me.Expired.Name = "Expired"
        Me.Expired.Size = New System.Drawing.Size(85, 61)
        Me.Expired.Text = "Expired: 0"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 64)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.AutoSize = False
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(65, 60)
        Me.ToolStripButton1.Text = "&Exit"
        Me.ToolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ToolStripButton1.ToolTipText = "Exit Application"
        '
        'Editor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(75, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 600)
        Me.Controls.Add(Me.Header)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Editor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.DataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.Connected, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGrid As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BorderShade As Guna.UI2.WinForms.Guna2BorderlessForm
    Friend WithEvents Header As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents Addlist As ToolStripButton
    Friend WithEvents Update As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents HeaderDrag As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents Count As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Connected As Guna.UI2.WinForms.Guna2CirclePictureBox
    Friend WithEvents Dialogue As Label
    Friend WithEvents Active As ToolStripLabel
    Friend WithEvents Expired As ToolStripLabel
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents ToolStripButton1 As ToolStripButton
End Class

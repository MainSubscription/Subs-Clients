﻿Module Config
    Public Version As String = "v1.0"
    Public Power As String = ""
    Public NameLogin As String
    Public UpdateID As String = "1"
End Module

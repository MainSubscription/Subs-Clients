﻿Imports System.Net.Http
Imports Newtonsoft.Json

Public Class Editor

    Public dataList As List(Of Dictionary(Of String, Object))
    Public dataTable As New DataTable()
    Public ActiveCount As Integer = 0

    Private Async Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGrid.AllowUserToResizeColumns = False  ' Allow column resizing (if needed)
        DataGrid.AllowUserToResizeRows = False

        ' Optional: Disable column resizing
        DataGrid.AllowUserToResizeColumns = False
        If Power = "Administrator" Or Power = "Read-Write-Update" Then
            Addlist.Enabled = True
            Update.Enabled = True
        ElseIf Power = "Update" Then
            Update.Enabled = True
        ElseIf Power = "Write" Then
            Addlist.Enabled = True
        End If
        Dialogue.Text = "Currently login as " & NameLogin
        Header.Text = "Rtool Editor " & Version
        TooltipImageChecker()
        ' Remove the row headers
        DataGrid.RowHeadersVisible = False
        ' Fetch and display data when the form loads
        Try
            Await FetchAndDisplayData()
        Catch ex As Exception

        End Try

    End Sub

    Public Async Function FetchAndDisplayData() As Task
        ' Define the Supabase REST API URL and API key
        dataTable = New DataTable
        Dim apiUrl As String = "https://azglsnlhsuinvibdfogc.supabase.co/rest/v1/SubsClient?select=*"
        Dim apiKey As String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF6Z2xzbmxoc3VpbnZpYmRmb2djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI4NDE3MzksImV4cCI6MjA0ODQxNzczOX0.-zSytP-ac5mk0ExNa3GuLsOus2_fNepBOpQJqQKYn2Q"

        ' Create an HttpClient instance
        Using client As New HttpClient()
            ' Add the API key to the request headers
            client.DefaultRequestHeaders.Add("apikey", apiKey)
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " & apiKey)

            Try
                ' Send the GET request
                Dim response As HttpResponseMessage = Await client.GetAsync(apiUrl)
                If Not response.IsSuccessStatusCode Then
                    ' Show error if the request fails
                    MessageBox.Show("HTTP Error: " & response.StatusCode & " - " & response.ReasonPhrase, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                ' Read the response content as a JSON string
                Dim jsonResponse As String = Await response.Content.ReadAsStringAsync()

                ' Deserialize the JSON into a list of dictionaries
                dataList = JsonConvert.DeserializeObject(Of List(Of Dictionary(Of String, Object)))(jsonResponse)

                ' Initialize counts for active and expired dates
                Dim activeCount As Integer = 0
                Dim expiredCount As Integer = 0

                ' Convert List to DataTable
                If dataList IsNot Nothing AndAlso dataList.Count > 0 Then
                    ' Create columns dynamically based on the first row's keys
                    For Each key As String In dataList(0).Keys
                        dataTable.Columns.Add(key)
                    Next

                    ' Populate rows and count active/expired dates
                    For Each row As Dictionary(Of String, Object) In dataList
                        Dim dataRow As DataRow = dataTable.NewRow()
                        For Each key As String In row.Keys
                            dataRow(key) = row(key)

                            ' Check the expiration date (assuming the key is "Date")
                            If key = "Date" AndAlso IsDate(row(key)) Then
                                Dim expirationDate As DateTime = CType(row(key), DateTime)
                                If expirationDate >= DateTime.Now Then
                                    activeCount += 1
                                Else
                                    expiredCount += 1
                                End If
                            End If
                        Next
                        dataTable.Rows.Add(dataRow)
                    Next
                End If

                Active.Text = "Active: " & activeCount
                Expired.Text = "Expired: " & expiredCount

                ' Bind the DataTable to the DataGridView
                DataGrid.DataSource = dataTable

                ' Format DataGrid columns
                DataGrid.Columns(0).Width = 40
                DataGrid.Columns(1).Width = 120
                DataGrid.Columns(2).Width = 85
                DataGrid.Columns(3).Width = 380
                DataGrid.Columns(4).Width = 131

                ' Display counts for active and expired records
                Count.Text = DataGrid.Rows.Count

            Catch ex As Exception
            End Try
        End Using
    End Function


    ' Function to search inside the dataList and update the DataGrid
    Private Sub SearchData()


        ' Get the search term from the search box (e.g., a TextBox named ToolStripTextBox1)
        Dim searchTerm As String = ToolStripTextBox1.Text.Trim()

        ' Check if search term is not empty
        If Not String.IsNullOrEmpty(searchTerm) Then
            ' Use LINQ to filter the dataList based on the search term
            Dim filteredData = dataList.Where(Function(row) row.Values.Any(Function(value) value.ToString().ToLower().Contains(searchTerm.ToLower()))).ToList()

            ' Clear the DataTable before adding filtered data
            dataTable.Clear()

            ' Convert the filtered data into DataTable and bind it
            If filteredData IsNot Nothing AndAlso filteredData.Count > 0 Then
                ' Populate rows for the filtered data
                For Each row As Dictionary(Of String, Object) In filteredData
                    Dim dataRow As DataRow = dataTable.NewRow()
                    For Each key As String In row.Keys
                        dataRow(key) = row(key)
                    Next
                    dataTable.Rows.Add(dataRow)
                Next

                ' Bind the DataTable to the DataGridView
                DataGrid.DataSource = dataTable
            Else
                ' No matching data found
                DataGrid.DataSource = Nothing
            End If
        Else
            ' If no search term is provided, display all data
            If dataList IsNot Nothing AndAlso dataList.Count > 0 Then
                ' Clear DataTable and repopulate with all data
                dataTable.Clear()

                For Each row As Dictionary(Of String, Object) In dataList
                    Dim dataRow As DataRow = dataTable.NewRow()
                    For Each key As String In row.Keys
                        dataRow(key) = row(key)
                    Next
                    dataTable.Rows.Add(dataRow)
                Next

                ' Bind the DataTable to the DataGridView
                DataGrid.DataSource = dataTable
            End If
        End If
        DataGrid.DataSource = dataTable
        DataGrid.Columns(0).Width = 40
        DataGrid.Columns(1).Width = 120
        DataGrid.Columns(2).Width = 85
        DataGrid.Columns(3).Width = 380
        DataGrid.Columns(4).Width = 131
        Count.Text = DataGrid.Rows.Count

    End Sub

    ' Event handler for the search button (or text changed event for the search box)
    Private Sub ToolStripButtonSearch_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        ' Call the SearchData method to filter and display results
        SearchData()
    End Sub

    ' Optionally, you can handle the search term change dynamically as the user types (for example, in a TextBox's TextChanged event)
    Private Sub ToolStripTextBox1_TextChanged(sender As Object, e As EventArgs) Handles ToolStripTextBox1.TextChanged
        ' Call the SearchData method on text change to filter data live
        SearchData()
    End Sub

    Public Sub TooltipImageChecker()
        ' Set the desired width and height
        Dim newWidth As Integer = 30
        Dim newHeight As Integer = 30

        ' Create a new Bitmap with the desired size
        Dim resizedBitmap As New Bitmap(newWidth, newHeight)

        ' Create a Graphics object to resize the image
        Using g As Graphics = Graphics.FromImage(resizedBitmap)
            g.DrawImage(My.Resources.searchimg, 0, 0, newWidth, newHeight)
        End Using
        ' Set the resized image to the ToolStripButton
        ToolStripButton2.Image = resizedBitmap
    End Sub

    Private Sub tsbtnOutput_Click(sender As Object, e As EventArgs) Handles Addlist.Click
        New_Customer.Update.Visible = False
        New_Customer.Submit.Visible = True
        New_Customer.Show()
    End Sub

    Private Sub Editor_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        End
    End Sub

    Private Sub DataGrid_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGrid.CellFormatting
        ' Ensure the column index is 3 (Date column)
        If e.RowIndex >= 0 AndAlso e.ColumnIndex = 2 Then
            ' Check if the cell value is a valid Date
            Dim cellValue As Object = e.Value
            If cellValue IsNot Nothing AndAlso IsDate(cellValue) Then
                ' Convert the cell value to DateTime
                Dim expirationDate As DateTime = CType(cellValue, DateTime)

                ' Compare the expiration date with the current date
                If expirationDate >= DateTime.Now.ToString("yyyy/MM/dd") Then
                    e.CellStyle.ForeColor = Color.Green
                Else
                    e.CellStyle.ForeColor = Color.Red
                End If
            End If
        End If
    End Sub

    Private Sub tsbtnInquiry_Click(sender As Object, e As EventArgs) Handles Update.Click
        UpdateID = DataGrid.CurrentRow.Cells(0).Value
        New_Customer.Nametxt.Text = DataGrid.CurrentRow.Cells(1).Value
        New_Customer.Expiration.Text = DataGrid.CurrentRow.Cells(2).Value
        New_Customer.Tagstxt.Text = DataGrid.CurrentRow.Cells(3).Value
        New_Customer.Keytxt.Text = DataGrid.CurrentRow.Cells(4).Value
        New_Customer.Update.Visible = True
        New_Customer.Submit.Visible = False
        New_Customer.Show()
        New_Customer.Keytxt.Focus()
    End Sub

    Private Sub DataGrid_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGrid.CellClick

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        End
    End Sub

    ' Mark the event handler as Async so that you can use Await inside it
    '    Private Async Sub ToolStripTextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ToolStripTextBox1.KeyDown
    '        Ensure that 'Enter' key is pressed
    '        If e.KeyCode = Keys.Enter Then
    '            Await the async function call
    '            Await DisplaySearch()
    '        End If
    '    End Sub

    '    Private Async Function DisplaySearch() As Task
    '        Define the Supabase REST API URL and API key
    '        Dim apiUrl As String = "https://azglsnlhsuinvibdfogc.supabase.co/rest/v1/SubsClient"
    '        Dim apiKey As String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF6Z2xzbmxoc3VpbnZpYmRmb2djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI3MTM4OTMsImV4cCI6MjA0ODI4OTg5M30.oY25wGdaxwVq18xazwOUWFzSfVkCY3I1RYv-sx259SQ"

    '         Get the search term from the search box (e.g., a TextBox named ToolStripTextBox1)
    '        Dim searchTerm As String = ToolStripTextBox1.Text.Trim()
    '        Dim encodedSearchTerm As String = Uri.EscapeDataString(searchTerm)

    '        If there 's a search term, add it to the query
    '            If Not String.IsNullOrEmpty(searchTerm) Then
    '                Modify the API URL to include filters for multiple columns:
    '                apiUrl = apiUrl & "?or=(Key.eq." & encodedSearchTerm & ")"
    '            Else
    '                If no search term, fetch all data
    '            apiUrl = "https://azglsnlhsuinvibdfogc.supabase.co/rest/v1/SubsClient"
    '                End If

    'Debugging:      Print the API URL to see what it's sending
    '                Console.WriteLine("API URL: " & apiUrl)

    '                Create an HttpClient instance
    '        Using client As New HttpClient()
    '                    Add the API key to the request headers
    '            client.DefaultRequestHeaders.Add("apikey", apiKey)
    '                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " & apiKey)

    '                    Try
    '                        Send the GET request
    '                Dim response As HttpResponseMessage = Await client.GetAsync(apiUrl)
    '                        response.EnsureSuccessStatusCode()

    '                        Read the response content as a JSON string
    '                Dim jsonResponse As String = Await response.Content.ReadAsStringAsync()

    '                        Deserialize the JSON into a list of dictionaries
    '                Dim dataList As List(Of Dictionary(Of String, Object)) = JsonConvert.DeserializeObject(Of List(Of Dictionary(Of String, Object)))(jsonResponse)
    '                        Dim dataTable As New DataTable()

    '                        Convert List to DataTable
    '                If dataList IsNot Nothing AndAlso dataList.Count > 0 Then
    '                            Create columns dynamically based on the first row's keys
    '                            For Each key As String In dataList(0).Keys
    '                                dataTable.Columns.Add(key)
    '                            Next

    '                            Populate rows
    '                    For Each row As Dictionary(Of String, Object) In dataList
    '                                Dim dataRow As DataRow = dataTable.NewRow()
    '                                For Each key As String In row.Keys
    '                                    dataRow(key) = row(key)
    '                                Next
    '                                dataTable.Rows.Add(dataRow)
    '                            Next
    '                        End If

    '                        Bind the DataTable to the DataGridView (automatically handles column creation)
    '                DataGrid.DataSource = dataTable

    '                    Catch ex As Exception
    '                        Handle errors
    '                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                    End Try
    '                End Using
    '    End Function




End Class

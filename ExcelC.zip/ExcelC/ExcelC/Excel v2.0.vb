﻿Imports System.Net.Http
Imports System.Net
Imports System.Text
Imports Newtonsoft.Json.Linq
Imports Octokit
Imports Windows.UI.Notifications
Imports Windows.Data.Xml.Dom
Imports System.Windows.Forms
Imports System.Text.RegularExpressions

Imports System.Runtime.InteropServices
Public Class Form1

    Public TimerMinimizeCount As Integer = 10
    Public HideTime As Integer = 15
    Public StopHide As Boolean = False

    Public repositoryOwner As String = "MainSubscription"
    Public repositoryName As String = "ExcelChat"
    Public branchName As String = "main"
    Public Token As String = "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"
    Public chatToolTip As New ToolTip()
    Public iniContent As String

    Public MainChat As Dictionary(Of String, String)
    Public UserUpdate As Dictionary(Of String, String)
    Public parsedIni As Dictionary(Of String, Dictionary(Of String, String))

    Public xLastChat As String = ""
    Public xLastName As String = ""
    Public xLastTime As Date

    'Public RedDotNotif As Dictionary(Of String, String)
    Public RedDotNotif As Boolean = True

    'Private WithEvents fileCheckTimer As New Timer()
    Private etag As String = "" ' Store the ETag for the GitHub file

    Private ReadOnly accessToken As String = Token
    Private ReadOnly fileUrl As String = "https://api.github.com/repos/MainSubscription/ExcelChat/contents/DataServer.ini"

    Public ErrorCD As Boolean = True

    Private Async Sub fileCheckTimer_Tick(sender As Object, e As EventArgs) Handles fileCheckTimer.Tick
        Try

            If Await HasFileChangedOnGitHub() Then
                'i want to empty the parsedini dictionary
                parsedIni.Clear()

                iniContent = GetDataServer("DataServer.ini")
                parsedIni = ParseIniContent(iniContent)


                Dim server As Dictionary(Of String, String) = parsedIni("Server")

                If server("Online") = False Then
                    End
                End If

                MainChat = parsedIni("MainChat")
                If MainChat("Chat") <> xLastChat Or MainChat("From") <> xLastName Or MainChat("Time") <> xLastTime Then
                    ShiftChatData()
                    If MainChat("From") = Namestr Then
                        AddChatBubble(MainChat("From"), MainChat("Chat"), True, MainChat("Time"))
                    Else
                        AddChatBubble(MainChat("From"), MainChat("Chat"), False, MainChat("Time"))
                    End If
                    If notification Then
                        If Me.Visible = False Or Me.WindowState = FormWindowState.Minimized Then
                            ShowToastNotification(MainChat("From"), MainChat("Chat"))
                        End If
                    End If

                    If RedDotNotif Then
                        RedDot.Show()
                        Dim parts() As String = RedDotL.Split(","c)
                        Dim x As Integer = Convert.ToInt32(parts(0).Trim()) ' 2
                        Dim y As Integer = Convert.ToInt32(parts(1).Trim()) ' 263
                        RedDot.Location = New Point(x, y)
                    End If

                    xLastTime = MainChat("Time")
                    xLastChat = MainChat("Chat")
                    xLastName = MainChat("From")
                End If


                ErrorCD = True
            End If
        Catch ex As Exception
            If ErrorCD Then
                ErrorCD = False
                MessageBox.Show("1 We're having a problem connecting to the Server.",
                    "Connection Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error)
            End If

            Exit Sub
        End Try
    End Sub

    Private Sub ShowToastNotification(decryptedName As String, decryptedChat As String)
        Dim toastXml As XmlDocument = ToastNotificationManager.GetTemplateContent(ToastTemplateType.ToastText01)
        Dim toastTextElement As IXmlNode = toastXml.GetElementsByTagName("text").Item(0)

        toastTextElement.AppendChild(toastXml.CreateTextNode($"Message: {decryptedChat}"))

        Dim toastNotification As New ToastNotification(toastXml)
        ToastNotificationManager.CreateToastNotifier(decryptedName).Show(toastNotification)

    End Sub
    Private Async Function HasFileChangedOnGitHub() As Task(Of Boolean)
        Try
            Using client As New HttpClient()
                client.DefaultRequestHeaders.Authorization = New Headers.AuthenticationHeaderValue("token", accessToken)
                client.DefaultRequestHeaders.UserAgent.ParseAdd("request")

                If Not String.IsNullOrEmpty(etag) Then
                    client.DefaultRequestHeaders.IfNoneMatch.ParseAdd(etag)
                End If

                Dim response As HttpResponseMessage = Await client.GetAsync(fileUrl)

                If response.StatusCode = HttpStatusCode.NotModified Then
                    ' File has not changed
                    Return False
                End If

                If response.IsSuccessStatusCode Then
                    ' Update the ETag for future requests
                    etag = response.Headers.ETag?.Tag
                    ErrorCD = True
                    Return True ' File has changed
                End If

            End Using
        Catch ex As Exception
            If ex.Message.Contains("Not Modified") Then
                Return False
            Else
                If ErrorCD Then
                    ErrorCD = False
                    MessageBox.Show($"An error occurred: {ex.Message}")
                End If
            End If
        End Try

        Return False
    End Function


    Public Function GetDataServer(Filepath As String) As String
        ' Your GitHub personal access token
        Dim accessToken As String = Token

        Dim decodedContent As String = ""
        Dim webClient As New WebClient()
        Dim GHUrl As String = $"https://api.github.com/repos/{repositoryOwner}/{repositoryName}/contents/{Filepath}?ref={branchName}"
        ' Add required headers
        Try
            webClient.Headers.Add("Authorization", "token " & accessToken)
            webClient.Headers.Add("User-Agent", "request")
            ' Make the GET request to the GitHub API


            Dim jsonContent As String = webClient.DownloadString(GHUrl)

            ' Parse the JSON response
            Dim jsonResponse As JObject = JObject.Parse(jsonContent)

            ' Extract the Base64-encoded content and decode it
            Dim encodedContent As String = jsonResponse("content").ToString()
            Dim bytes As Byte() = Convert.FromBase64String(encodedContent)
            decodedContent = Encoding.UTF8.GetString(bytes)
            ErrorCD = True
        Catch ex As Exception
            ' Handle any errors that occur during the request
            If ErrorCD Then
                ErrorCD = False
                MessageBox.Show($"3 An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        End Try

        Return decodedContent
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetHook()
        'RedDot.Show()
        iniContent = GetDataServer("DataServer.ini")
        parsedIni = ParseIniContent(iniContent)
        MainChat = parsedIni("MainChat")
        'RedDotNotif = parsedIni("RedDot")
        Try
            Dim server As Dictionary(Of String, String) = parsedIni("Server")

            If server("Online") = False Then
                End
            End If
        Catch ex As Exception
            End
        End Try


        Dim user1 As Dictionary(Of String, String) = parsedIni("User1")
        Dim user2 As Dictionary(Of String, String) = parsedIni("User2")

        For i As Integer = 1 To 10
            Dim prevChat As Dictionary(Of String, String) = parsedIni($"PrevChat{i}")

            ' Check if the message is from the user and add chat bubble
            If prevChat("From") = Namestr Then
                AddChatBubble(prevChat("From"), prevChat("Chat"), True, prevChat("Time"))
            Else
                AddChatBubble(prevChat("From"), prevChat("Chat"), False, prevChat("Time"))
            End If
        Next

        If MainChat("From") = Namestr Then
            AddChatBubble(MainChat("From"), MainChat("Chat"), True, MainChat("Time"))
        Else
            AddChatBubble(MainChat("From"), MainChat("Chat"), False, MainChat("Time"))
        End If
        xLastName = MainChat("From")
        xLastTime = MainChat("Time")
        xLastChat = MainChat("Chat")

    End Sub


    Private Sub ShowDictionaryData()
        ' Assuming parsedIni is a dictionary holding the chat data
        For i As Integer = 1 To 10
            Dim prevChat As Dictionary(Of String, String) = parsedIni($"PrevChat{i}")

            ' Loop through each key-value pair in the dictionary
            Dim chatData As String = ""
            For Each key As String In prevChat.Keys
                chatData &= $"{key}: {prevChat(key)}" & vbCrLf
            Next

            ' Show the data in a MessageBox
            MessageBox.Show($"Data for PrevChat{i}:" & vbCrLf & chatData)
        Next
    End Sub


    ' Declare a function to parse the INI content
    Public Function ParseIniContent(iniContent As String) As Dictionary(Of String, Dictionary(Of String, String))
        Dim sections As New Dictionary(Of String, Dictionary(Of String, String))()
        Dim currentSection As String = ""
        Dim currentSectionDict As New Dictionary(Of String, String)()

        ' Split content by lines
        Dim lines() As String = iniContent.Split(New String() {Environment.NewLine}, StringSplitOptions.None)

        For Each line As String In lines
            ' Ignore comments and empty lines
            If String.IsNullOrWhiteSpace(line) OrElse line.StartsWith(";") Then
                Continue For
            End If

            ' Check for section headers (e.g. [Section])
            If line.StartsWith("[") AndAlso line.EndsWith("]") Then
                ' Save the previous section if exists
                If currentSection <> "" Then
                    sections.Add(currentSection, currentSectionDict)
                End If

                ' Start a new section
                currentSection = line.Trim("["c, "]"c)
                currentSectionDict = New Dictionary(Of String, String)()

            Else
                ' Handle key-value pairs (key=value)
                Dim splitLine() As String = line.Split("="c)
                If splitLine.Length = 2 Then
                    currentSectionDict(splitLine(0).Trim()) = splitLine(1).Trim()
                End If
            End If
        Next

        ' Add the last section
        If currentSection <> "" Then
            sections.Add(currentSection, currentSectionDict)
        End If

        Return sections
    End Function




    Public Sub ShiftChatData()
        ' Assuming parsedIni is a dictionary holding the chat data
        For i As Integer = 1 To 9 ' Start from 1 and go up to 9
            Dim prevChat As Dictionary(Of String, String) = parsedIni($"PrevChat{i}")
            Dim nextChat As Dictionary(Of String, String) = parsedIni($"PrevChat{i + 1}")

            ' Copy the data from nextPrevChat to prevChat
            prevChat("From") = nextChat("From")
            prevChat("Chat") = nextChat("Chat")
            prevChat("Time") = nextChat("Time")
        Next
        ' Set PrevChat10 to a new chat (this will be the latest chat added)
        parsedIni("PrevChat10")("From") = MainChat("From")
        parsedIni("PrevChat10")("Chat") = MainChat("Chat")
        parsedIni("PrevChat10")("Time") = MainChat("Time")

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Send()
    End Sub

    Private Sub message_KeyDown(sender As Object, e As KeyEventArgs) Handles message.KeyDown
        If e.KeyCode = Keys.Enter AndAlso Not e.Shift Then
            Send()
            e.SuppressKeyPress = True
        End If
    End Sub

    Public Sub Send()
        If Not String.IsNullOrWhiteSpace(message.Text) Then
            Try
                message.Enabled = False
                Sendmessage = True

                MainChat("Chat") = message.Text
                MainChat("From") = Namestr
                MainChat("Time") = DateTime.Now.ToString("yyyy/MM/dd h:mm:ss tt")
                Dim dnow As DateTime = DateTime.Now

                UploadIniFile()

                If Sendmessage Then
                    AddChatBubble(MainChat("From"), MainChat("Chat"), True, MainChat("Time"))
                    xLastChat = message.Text
                    xLastName = Namestr
                    xLastTime = DateTime.Now.ToString("yyyy/MM/dd h:mm:ss tt")
                    message.Text = ""
                    Sendmessage = False


                End If
                TimerMinimizeCount = 10
            Catch ex As Exception

            End Try
        End If
    End Sub
    Public Async Sub UploadIniFile()
        Try
            ' Convert the parsedIni dictionary to a string representing the INI file
            Dim iniContent As String = ConvertNestedDictionaryToIni(parsedIni)

            ' Create a commit message for the update
            Dim commitMessage As String = TimeOfDay.ToString("(hh-mm tt)") & " UPDATE.ini"

            ' Initialize the GitHubUpdater with the access token
            Dim updater As New GitHubUpdater(Token)

            ' Create a list of file updates
            Dim updates As New List(Of FileUpdateInfo) From {
            New FileUpdateInfo With {
                .FilePath = "DataServer.ini",  ' The path to your INI file on GitHub
                .NewContent = iniContent
            }
        }

            ' Update the file on GitHub
            Await updater.UpdateFiles(repositoryOwner, repositoryName, updates, branchName, commitMessage)
            ErrorCD = True
        Catch ex As Exception
            If ErrorCD Then
                ErrorCD = False

            End If
        End Try

    End Sub

    Public Function ConvertNestedDictionaryToIni(dictionary As Dictionary(Of String, Dictionary(Of String, String))) As String
        Dim iniContent As New StringBuilder()

        For Each outerKvp As KeyValuePair(Of String, Dictionary(Of String, String)) In dictionary
            iniContent.AppendLine($"[{outerKvp.Key}]")  ' Create a section header
            For Each innerKvp As KeyValuePair(Of String, String) In outerKvp.Value
                iniContent.AppendLine($"{innerKvp.Key}={innerKvp.Value}")
            Next
            iniContent.AppendLine()  ' Blank line between sections
        Next

        Return iniContent.ToString()
    End Function

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        End
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub TimerMinimize_Tick(sender As Object, e As EventArgs) Handles TimerMinimize.Tick
        If Me.WindowState = FormWindowState.Normal Then
            If RedDot.Visible Then
                RedDot.Hide()
            End If
            StopHide = False
            HideTime = 15
            If TimerMinimizeCount = 0 Then
                Me.WindowState = FormWindowState.Minimized

            Else
                TimerMinimizeCount -= 1
            End If
        Else
            TimerMinimizeCount = 10
        End If

        If Me.WindowState = FormWindowState.Minimized Then

            If StopHide = False Then
                If HideTime = 0 Then
                    Me.Hide()
                    StopHide = True

                Else
                    HideTime -= 1
                End If
            End If

        End If

    End Sub

    Public homepresscount As Integer = 2
    Public HomePressInterval As Boolean = True

    Private hHook As IntPtr = IntPtr.Zero

    Private Const WH_KEYBOARD_LL As Integer = 13

    Private hookProc As LowLevelKeyboardProcDelegate = Nothing

    Private Delegate Function LowLevelKeyboardProcDelegate(nCode As Integer, wParam As IntPtr, lParam As IntPtr) As IntPtr

    <StructLayout(LayoutKind.Sequential)>
    Private Structure KBDLLHOOKSTRUCT
        Public vkCode As UInteger
        Public scanCode As UInteger
        Public flags As UInteger
        Public time As UInteger
        Public dwExtraInfo As IntPtr
    End Structure

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function SetWindowsHookEx(idHook As Integer, lpfn As LowLevelKeyboardProcDelegate, hMod As IntPtr, dwThreadId As UInteger) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function UnhookWindowsHookEx(hhk As IntPtr) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function CallNextHookEx(hhk As IntPtr, nCode As Integer, wParam As IntPtr, lParam As IntPtr) As IntPtr
    End Function

    ' The hook callback function
    Private Function LowLevelKeyboardProc(nCode As Integer, wParam As IntPtr, lParam As IntPtr) As IntPtr
        If nCode >= 0 Then
            Dim keyInfo As KBDLLHOOKSTRUCT = Marshal.PtrToStructure(Of KBDLLHOOKSTRUCT)(lParam)
            Dim vkCode As Keys = CType(keyInfo.vkCode, Keys)

            ' Detecting Ctrl + Home
            If (Control.ModifierKeys And Keys.Control) = Keys.Control AndAlso vkCode = Keys.Home Then

                If HomePressInterval Then
                    HomePressInterval = False
                    Timer3.Start()

                    If Not Me.Visible Then
                        TimerMinimizeCount = 10
                        HideTime = 15
                        Me.Visible = True
                        Me.WindowState = FormWindowState.Normal
                        Me.TopMost = True
                        Me.TopMost = False
                        message.Focus()
                    Else
                        Me.WindowState = FormWindowState.Minimized
                        Me.Visible = False
                    End If
                End If
            End If
        End If

        Return CallNextHookEx(hHook, nCode, wParam, lParam)
    End Function


    Private Sub SetHook()
        hookProc = New LowLevelKeyboardProcDelegate(AddressOf LowLevelKeyboardProc)
        hHook = SetWindowsHookEx(WH_KEYBOARD_LL, hookProc, Marshal.GetHINSTANCE(System.Reflection.Assembly.GetExecutingAssembly().GetModules()(0)), 0)
    End Sub

    Private Sub UnsetHook()
        If hHook <> IntPtr.Zero Then
            UnhookWindowsHookEx(hHook)
            hHook = IntPtr.Zero
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        If homepresscount <> 0 Then
            homepresscount -= 1
        Else
            homepresscount = 3
            HomePressInterval = True
            Timer3.Stop()
        End If
    End Sub

    Private Sub message_TextChanged(sender As Object, e As EventArgs) Handles message.TextChanged
        TimerMinimizeCount = 10
    End Sub

    Private previousScrollValue As Integer = 0 ' Store previous scroll position


    Private Sub chatPanel_MouseWheel(sender As Object, e As MouseEventArgs) Handles chatPanel.MouseWheel
        If e.Delta > 0 Then
            ' User scrolled up
            TimerMinimizeCount = 10
        ElseIf e.Delta < 0 Then
            ' User scrolled down
            TimerMinimizeCount = 10
        End If
    End Sub

    Private Sub Form1_LocationChanged(sender As Object, e As EventArgs) Handles MyBase.LocationChanged
        TimerMinimizeCount = 10
    End Sub

    Private Sub Label1_MouseUp(sender As Object, e As MouseEventArgs) Handles Label1.MouseUp
        UserUpdate = parsedIni(UserNo)
        UserUpdate("ChatLocation") = Me.Location.X & "," & Me.Location.Y
        UploadIniFile()
    End Sub

End Class


Public Class GitHubUpdater
    Private ReadOnly githubClient As GitHubClient
    Private ErrorCD As Boolean = True
    Public Sub New(accessToken As String)
        Dim credentials = New Credentials(accessToken)
        githubClient = New GitHubClient(New ProductHeaderValue("APIforUpdate"))
        githubClient.Credentials = credentials
    End Sub

    Public Async Function UpdateFiles(repositoryOwner As String, repositoryName As String, updates As List(Of FileUpdateInfo), branchName As String, commitMessage As String) As Task
        Try
            For Each updateInfo In updates
                Dim existingFile = Await githubClient.Repository.Content.GetAllContents(repositoryOwner, repositoryName, updateInfo.FilePath)

                Dim updateChangeSet = Await githubClient.Repository.Content.UpdateFile(
                    repositoryOwner,
                    repositoryName,
                    updateInfo.FilePath,
                    New UpdateFileRequest(
                        commitMessage,
                        updateInfo.NewContent,
                        existingFile.First().Sha,
                        branchName)
                )
            Next
            Sendmessage = True
            ErrorCD = True
        Catch ex As Exception
            Sendmessage = False
            If ErrorCD Then
                If Sendmessage Then
                    Sendmessage = False
                    MsgBox($"4 An error occurred: can't send any message right now. Connection error")
                Else
                    MsgBox($"5 An error occurred: {ex.Message}")
                End If
                ErrorCD = False

            End If
        End Try

        Form1.iniContent = Form1.GetDataServer("DataServer.ini")
        Form1.parsedIni = Form1.ParseIniContent(Form1.iniContent)
        Form1.MainChat = Form1.parsedIni("MainChat")
        Form1.ShiftChatData()

        Form1.message.Enabled = True
        Form1.message.Focus()
    End Function
End Class

Public Class FileUpdateInfo
    Public Property FilePath As String
    Public Property NewContent As String
End Class
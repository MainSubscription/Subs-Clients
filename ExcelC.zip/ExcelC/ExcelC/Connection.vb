﻿Module Connection
    Public Namestr As String
    Public UserNo As String = ""
    Public RedDotL As String
    Public notification As Boolean
    Public Sendmessage As Boolean = False

    Public ServerFile As String = "DataServer.ini"

    Public Sub AddChatBubble(senderName As String, message As String, isFromSelf As Boolean, Time As Date)
        ' Create a label for the sender's name
        Dim nameLabel As New Label()
        nameLabel.Text = senderName
        nameLabel.Font = New Font("Segoe UI", 8, FontStyle.Bold)
        nameLabel.ForeColor = Color.Gray
        nameLabel.BackColor = Color.Transparent
        nameLabel.AutoSize = True

        ' Set text alignment based on sender
        nameLabel.TextAlign = If(isFromSelf, ContentAlignment.MiddleRight, ContentAlignment.MiddleLeft)

        ' Create a label for the chat message
        Dim chatLabel As New Label()
        chatLabel.Text = message
        chatLabel.AutoSize = True
        chatLabel.Font = New Font("Segoe UI", 10, FontStyle.Regular)
        chatLabel.Padding = New Padding(5)
        chatLabel.BorderStyle = BorderStyle.FixedSingle
        chatLabel.BackColor = If(isFromSelf, Color.White, Color.White)
        chatLabel.ForeColor = Color.Black
        chatLabel.MaximumSize = New Size(Form1.chatPanel.Width - 40, 0)

        ' Create a label for the time (including date if not same day)
        Dim timeLabel As New Label()

        ' Check if the date is the same as the previous chat's date
        Dim previousChatTime As DateTime = GetPreviousChatTime() ' Implement logic to get the previous chat's time

        ' If same date, show only the time, otherwise show the full date
        If Time.Date = previousChatTime.Date Then
            timeLabel.Text = Format(Time, "hh:mm tt") ' Show only time
        Else
            timeLabel.Text = Format(Time, "MM/dd/yyyy hh:mm tt") ' Show date and time
        End If

        timeLabel.Font = New Font("Segoe UI", 7, FontStyle.Italic)
        timeLabel.ForeColor = Color.Gray
        timeLabel.BackColor = Color.Transparent
        timeLabel.AutoSize = True
        timeLabel.TextAlign = If(isFromSelf, ContentAlignment.MiddleRight, ContentAlignment.MiddleLeft)

        Form1.chatToolTip.SetToolTip(chatLabel, Format(Time, "hh:mm tt MM/dd/yyyy"))

        Form1.chatPanel.Controls.Add(nameLabel)
        Form1.chatPanel.Controls.Add(chatLabel)
        Form1.chatPanel.Controls.Add(timeLabel)

        ' Calculate the top position for the new chat bubble
        Dim padding As Integer = 10
        Dim topPosition As Integer = Form1.chatPanel.Controls.Cast(Of Control).Max(Function(c) c.Bottom) + padding

        ' Adjust the position of the nameLabel, chatLabel, and timeLabel
        nameLabel.Left = If(isFromSelf, Form1.chatPanel.Width - nameLabel.Width - 20, 10)
        nameLabel.Top = topPosition

        chatLabel.Left = If(isFromSelf, Form1.chatPanel.Width - chatLabel.Width - 20 - 2, 10)
        chatLabel.Top = nameLabel.Bottom + 2 ' Slight gap between name and message

        timeLabel.Left = If(isFromSelf, Form1.chatPanel.Width - timeLabel.Width - 20 - 2, 10)
        timeLabel.Top = chatLabel.Bottom + 2 ' Slight gap between message and time

        ' Scroll to the bottom of the chatPanel
        Form1.chatPanel.VerticalScroll.Value = Form1.chatPanel.VerticalScroll.Maximum
        Form1.chatPanel.PerformLayout()
    End Sub

    ' Function to get the previous chat's time
    Private Function GetPreviousChatTime() As DateTime
        ' Implement logic to retrieve the previous chat's timestamp from your chat data
        ' For example, you can get the last message's time from a collection or database
        ' Here, I'll return the current date as a placeholder
        Return DateTime.Now
    End Function
End Module

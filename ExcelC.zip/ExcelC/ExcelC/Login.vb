﻿Imports System.Net.Http
Imports System.Net
Imports System.Text
Imports Newtonsoft.Json.Linq
Imports Octokit
Imports System.Windows.Forms
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Runtime.InteropServices
Public Class Login
    Public repositoryOwner As String = "MainSubscription"
    Public repositoryName As String = "ExcelChat"
    Public branchName As String = "main"
    Public Token As String = "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"

    Private mutex As Mutex = Nothing

    Private iniContent As String
    Private parsedIni As Dictionary(Of String, Dictionary(Of String, String))

    Public user1 As Dictionary(Of String, String)
    Public user2 As Dictionary(Of String, String)
    Public user3 As Dictionary(Of String, String)

    Private Sub loginbtn_Click(sender As Object, e As EventArgs) Handles loginbtn.Click
        Dim Location As String
        If user.Text = user1("Username") And pass.Text = user1("Password") Then
            Namestr = user1("Name")
            Location = user1("ChatLocation")
            RedDotL = user1("RedDotLocation")
            UserNo = "User1"
            notification = user1("Notification")
        ElseIf user.Text = user2("Username") And pass.Text = user2("Password") Then
            Namestr = user2("Name")
            Location = user2("ChatLocation")
            RedDotL = user2("RedDotLocation")
            UserNo = "User2"
            notification = user2("Notification")
        ElseIf user.Text = user3("Username") And pass.Text = user3("Password") Then
            Namestr = user3("Name")
            Location = user3("ChatLocation")
            RedDotL = user3("RedDotLocation")
            UserNo = "User3"
            notification = user3("Notification")
        Else
            MessageBox.Show("Invalid Username/ Password!", "DMR Online", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If
        Me.Hide()
        Form1.Show()
        Dim parts() As String = Location.Split(","c)
        Dim x As Integer = Convert.ToInt32(parts(0).Trim()) ' 2
        Dim y As Integer = Convert.ToInt32(parts(1).Trim()) ' 263
        Form1.Location = New Point(x, y)


    End Sub
    Public Function GetDataServer(Filepath As String) As String
        ' Your GitHub personal access token
        Dim accessToken As String = Token

        Dim decodedContent As String = ""
        Dim webClient As New WebClient()
        Dim GHUrl As String = $"https://api.github.com/repos/{repositoryOwner}/{repositoryName}/contents/{Filepath}?ref={branchName}"
        ' Add required headers
        webClient.Headers.Add("Authorization", "token " & accessToken)
        webClient.Headers.Add("User-Agent", "request")
        ' Make the GET request to the GitHub API
        Try

            Dim jsonContent As String = webClient.DownloadString(GHUrl)

            ' Parse the JSON response
            Dim jsonResponse As JObject = JObject.Parse(jsonContent)

            ' Extract the Base64-encoded content and decode it
            Dim encodedContent As String = jsonResponse("content").ToString()
            Dim bytes As Byte() = Convert.FromBase64String(encodedContent)
            decodedContent = Encoding.UTF8.GetString(bytes)

        Catch ex As Exception
            ' Handle any errors that occur during the request

        End Try

        Return decodedContent
    End Function

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Const appName As String = "LOve"
        'Dim createdNew As Boolean

        '' Create a new Mutex with a unique name
        'mutex = New Mutex(True, appName, createdNew)

        '' Check if the Mutex was created new or if it already existed
        'If Not createdNew Then
        '    ' If the Mutex already exists, it means the program is already running
        '    MessageBox.Show("The program is already running!", "Already Running", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        '    Environment.Exit(0) ' Exit the new instance
        'End If
        Try
            iniContent = GetDataServer(ServerFile)
            parsedIni = ParseIniContent(iniContent)
            user1 = parsedIni("User1")
            user2 = parsedIni("User2")
            user3 = parsedIni("User3")
        Catch ex As Exception
            MessageBox.Show($"An error occurred: can't connect to the main server", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End

        End Try

    End Sub

    Public Function ParseIniContent(iniContent As String) As Dictionary(Of String, Dictionary(Of String, String))
        Dim sections As New Dictionary(Of String, Dictionary(Of String, String))()
        Dim currentSection As String = ""
        Dim currentSectionDict As New Dictionary(Of String, String)()

        ' Split content by lines
        Dim lines() As String = iniContent.Split(New String() {Environment.NewLine}, StringSplitOptions.None)

        For Each line As String In lines
            ' Ignore comments and empty lines
            If String.IsNullOrWhiteSpace(line) OrElse line.StartsWith(";") Then
                Continue For
            End If

            ' Check for section headers (e.g. [Section])
            If line.StartsWith("[") AndAlso line.EndsWith("]") Then
                ' Save the previous section if exists
                If currentSection <> "" Then
                    sections.Add(currentSection, currentSectionDict)
                End If

                ' Start a new section
                currentSection = line.Trim("["c, "]"c)
                currentSectionDict = New Dictionary(Of String, String)()

            Else
                ' Handle key-value pairs (key=value)
                Dim splitLine() As String = line.Split("="c)
                If splitLine.Length = 2 Then
                    currentSectionDict(splitLine(0).Trim()) = splitLine(1).Trim()
                End If
            End If
        Next

        ' Add the last section
        If currentSection <> "" Then
            sections.Add(currentSection, currentSectionDict)
        End If

        Return sections
    End Function

    Private Sub user_KeyDown(sender As Object, e As KeyEventArgs) Handles user.KeyDown
        If e.KeyCode = Keys.Enter Then
            pass.Focus()
        End If
    End Sub

    Private Sub pass_KeyDown(sender As Object, e As KeyEventArgs) Handles pass.KeyDown
        If e.KeyCode = Keys.Enter Then
            loginbtn.PerformClick()
        End If
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        End
    End Sub

    Public Function GetDataServer1(Filepath As String, repoOwner As String, repoName As String, branchname As String, tokenx As String) As String
        Dim accessToken As String = tokenx
        Dim decodedContent As String = ""
        Dim webClient As New WebClient()
        Dim GHUrl As String = $"https://api.github.com/repos/{repoOwner}/{repoName}/contents/{Filepath}?ref={branchname}"

        ' Add required headers
        webClient.Headers.Add("Authorization", "token " & accessToken)
        webClient.Headers.Add("User-Agent", "request")

        Try
            Dim jsonContent As String = webClient.DownloadString(GHUrl)
            Dim jsonResponse As JObject = JObject.Parse(jsonContent)

            ' Extract Base64-encoded content and decode it
            Dim encodedContent As String = jsonResponse("content").ToString()
            Dim bytes As Byte() = Convert.FromBase64String(encodedContent)
            decodedContent = Encoding.UTF8.GetString(bytes)

        Catch ex As Exception
            MsgBox("Error fetching data: " & ex.Message)
        End Try

        Return decodedContent
    End Function

    Public Function ParseInibody(iniContent As String) As Dictionary(Of String, Dictionary(Of String, String))
        Dim sections As New Dictionary(Of String, Dictionary(Of String, String))()
        Dim currentSection As String = ""
        Dim currentSectionDict As New Dictionary(Of String, String)()

        ' Split content by lines
        Dim lines() As String = iniContent.Split(New String() {Environment.NewLine}, StringSplitOptions.None)

        For Each line As String In lines
            ' Ignore comments and empty lines
            If String.IsNullOrWhiteSpace(line) OrElse line.StartsWith(";") Then
                Continue For
            End If

            ' Check for section headers (e.g. [Section])
            If line.StartsWith("[") AndAlso line.EndsWith("]") Then
                ' Save the previous section if exists
                If currentSection <> "" Then
                    sections.Add(currentSection, currentSectionDict)
                End If

                ' Start a new section
                currentSection = line.Trim("["c, "]"c)
                currentSectionDict = New Dictionary(Of String, String)()

            Else
                ' Handle key-value pairs (key=value)
                Dim splitLine() As String = line.Split("="c)
                If splitLine.Length = 2 Then
                    currentSectionDict(splitLine(0).Trim()) = splitLine(1).Trim()
                End If
            End If
        Next

        ' Add the last section
        If currentSection <> "" Then
            sections.Add(currentSection, currentSectionDict)
        End If

        Return sections
    End Function
End Class
﻿Imports System.Net.Http
Imports System.Net
Imports System.Text
Imports Newtonsoft.Json.Linq
Imports Octokit
Imports System.Windows.Forms
Imports System.Text.RegularExpressions

Imports System.Runtime.InteropServices
Public Class RedDot

    Public repositoryOwner As String = "MainSubscription"
    Public repositoryName As String = "ExcelChat"
    Public branchName As String = "main"
    Public Token As String = "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"

    Public iniContent As String
    Public parsedIni1 As Dictionary(Of String, Dictionary(Of String, String))
    Private UserUpdate As Dictionary(Of String, String)
    Private Sub RedDot_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        iniContent = GetDataServer("DataServer.ini")
        parsedIni1 = ParseIniContent(iniContent)
        Me.BackColor = Color.Black
        Me.TransparencyKey = Color.Black
        Me.FormBorderStyle = FormBorderStyle.None
    End Sub

    Private Sub Notif_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackColor = Color.Black
        Me.TransparencyKey = Color.Black
        Me.FormBorderStyle = FormBorderStyle.None
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        MyBase.OnPaint(e)
        e.Graphics.FillRectangle(New SolidBrush(Me.TransparencyKey), Me.ClientRectangle)
    End Sub

    Public Function GetDataServer(Filepath As String) As String
        ' Your GitHub personal access token
        Dim accessToken As String = Token

        Dim decodedContent As String = ""
        Dim webClient As New WebClient()
        Dim GHUrl As String = $"https://api.github.com/repos/{repositoryOwner}/{repositoryName}/contents/{Filepath}?ref={branchName}"
        ' Add required headers
        webClient.Headers.Add("Authorization", "token " & accessToken)
        webClient.Headers.Add("User-Agent", "request")
        ' Make the GET request to the GitHub API
        Try

            Dim jsonContent As String = webClient.DownloadString(GHUrl)

            ' Parse the JSON response
            Dim jsonResponse As JObject = JObject.Parse(jsonContent)

            ' Extract the Base64-encoded content and decode it
            Dim encodedContent As String = jsonResponse("content").ToString()
            Dim bytes As Byte() = Convert.FromBase64String(encodedContent)
            decodedContent = Encoding.UTF8.GetString(bytes)

        Catch ex As Exception
            ' Handle any errors that occur during the request
            MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Return decodedContent
    End Function
    Public Function ParseIniContent(iniContent As String) As Dictionary(Of String, Dictionary(Of String, String))
        Dim sections As New Dictionary(Of String, Dictionary(Of String, String))()
        Dim currentSection As String = ""
        Dim currentSectionDict As New Dictionary(Of String, String)()

        ' Split content by lines
        Dim lines() As String = iniContent.Split(New String() {Environment.NewLine}, StringSplitOptions.None)

        For Each line As String In lines
            ' Ignore comments and empty lines
            If String.IsNullOrWhiteSpace(line) OrElse line.StartsWith(";") Then
                Continue For
            End If

            ' Check for section headers (e.g. [Section])
            If line.StartsWith("[") AndAlso line.EndsWith("]") Then
                ' Save the previous section if exists
                If currentSection <> "" Then
                    sections.Add(currentSection, currentSectionDict)
                End If

                ' Start a new section
                currentSection = line.Trim("["c, "]"c)
                currentSectionDict = New Dictionary(Of String, String)()

            Else
                ' Handle key-value pairs (key=value)
                Dim splitLine() As String = line.Split("="c)
                If splitLine.Length = 2 Then
                    currentSectionDict(splitLine(0).Trim()) = splitLine(1).Trim()
                End If
            End If
        Next

        ' Add the last section
        If currentSection <> "" Then
            sections.Add(currentSection, currentSectionDict)
        End If

        Return sections
    End Function
    Private Sub PictureBox1_MouseUp(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseUp
        UserUpdate = parsedIni1(UserNo)
        UserUpdate("RedDotLocation") = Me.Location.X & "," & Me.Location.Y
        UploadIniFile()
    End Sub

    Public Async Sub UploadIniFile()
        ' Convert the parsedIni dictionary to a string representing the INI file
        Dim iniContent As String = ConvertNestedDictionaryToIni(parsedIni1)

        ' Create a commit message for the update
        Dim commitMessage As String = TimeOfDay.ToString("(hh-mm tt)") & " UPDATE.ini"

        ' Initialize the GitHubUpdater with the access token
        Dim updater As New GitHubUpdater(Token)

        ' Create a list of file updates
        Dim updates As New List(Of FileUpdateInfo) From {
        New FileUpdateInfo With {
            .FilePath = "DataServer.ini",  ' The path to your INI file on GitHub
            .NewContent = iniContent
        }
    }

        ' Update the file on GitHub
        Await updater.UpdateFiles(repositoryOwner, repositoryName, updates, branchName, commitMessage)
    End Sub

    Public Function ConvertNestedDictionaryToIni(dictionary As Dictionary(Of String, Dictionary(Of String, String))) As String
        Dim iniContent As New StringBuilder()

        For Each outerKvp As KeyValuePair(Of String, Dictionary(Of String, String)) In dictionary
            iniContent.AppendLine($"[{outerKvp.Key}]")  ' Create a section header
            For Each innerKvp As KeyValuePair(Of String, String) In outerKvp.Value
                iniContent.AppendLine($"{innerKvp.Key}={innerKvp.Value}")
            Next
            iniContent.AppendLine()  ' Blank line between sections
        Next

        Return iniContent.ToString()
    End Function
End Class